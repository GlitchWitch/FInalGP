﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class WinCol : MonoBehaviour {

 void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            Application.LoadLevel(2);
        }
    }

}
