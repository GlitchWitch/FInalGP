﻿using UnityEngine;
using System.Collections;

public class dudeFollow : MonoBehaviour {

    private DudeMove moveScript;
    public Transform eyes;
    public float sightRange = 3f;

    public Transform Character; // Target Object to follow
    public float speed=0.1F; // Enemy speed
    public Vector3 directionOfCharacter;
    public bool challenged=false;


	// Use this for initialization
	void Start () {
        Character = GameObject.FindGameObjectWithTag("Player").transform;
        moveScript = GetComponent<DudeMove>();
	}
	
	// Update is called once per frame
	void Update () {

        Vector3 pos = transform.position;
        pos.z = 0;
        transform.position = pos;
        Follow();
	}

    public void Follow()
    {
        if (challenged == true) {
            directionOfCharacter = Character.transform.position - transform.position;
            directionOfCharacter = directionOfCharacter.normalized;    // Get Direction to Move Towards
            transform.Translate (directionOfCharacter * speed, Space.World);
            moveScript.enabled = false;
                        }
        else if (challenged == false)
        {
            moveScript.enabled = true;
        }
    }

    
}
