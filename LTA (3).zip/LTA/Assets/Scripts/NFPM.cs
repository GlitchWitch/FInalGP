﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class NFPM : MonoBehaviour
{
    public Text livesText; 
    GameManager gameManager;
    private Movement controller;
    public Vector2 Direction = new Vector2(1, 0);
    public float speed = 10;
    private Vector3 moveTranslation;
    public static int lives = 3;
    Text LivesText;


    // Use this for initialization
    void Start()
    {
        controller = GetComponent<Movement>();
        LivesText = GameObject.FindGameObjectWithTag("LivesText").GetComponent<Text>();
        gameManager = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (this.controller.IsKeyDown)
        {
            this.Direction = this.controller.direction;
        }
        else
        {
            this.Direction = new Vector2(0, 0);
        }

        this.moveTranslation = new Vector3(this.Direction.x, this.Direction.y) * Time.deltaTime * this.speed;
        this.transform.position += new Vector3(this.moveTranslation.x, this.moveTranslation.y);
        livesText.text = "Lives: " + gameManager.lives.ToString();
    }

    public void Death()
    {
        
        //print("player should die");


        //gameManager.lives--;
        //if (gameManager.lives >= 1)
        //{
        //    Application.LoadLevel(0);
        //}
        //else if (gameManager.lives <= 0)
        //{
              Application.LoadLevel(1);
        //}
    }
}
