﻿using UnityEngine;
using System.Collections;

public class fuckthisbutton : MonoBehaviour
{

    void OnGUI()
    {
        if (GUI.Button(new Rect(10, 10, 75, 75), "RESTART"))
            Application.LoadLevel(0);
            Debug.Log("Clicked the button");

    }
}
