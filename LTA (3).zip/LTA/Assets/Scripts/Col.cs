﻿using UnityEngine;
using System.Collections;

public class Col : MonoBehaviour
{
      
    public dudeFollow df;
    public CircleCollider2D trigger;
    public CircleCollider2D death;
    public GameObject player;
    public NFPM buttono;
    

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        
        Debug.Log("Hit");
  
            if (col.CompareTag("Player"))
            {
                if(trigger)
                {
                    df = this.GetComponent<dudeFollow>();
                    df.challenged = true;
                    df.Follow();
                    Debug.Log("HitPlayer");

                    if (death)
                    {
                        //player.SetActive(false);
                        player.GetComponent<Renderer>().enabled = false;
                        //player.gameObject.renderer = false;
                        df.challenged = false;
                        df.Follow();
                        buttono = player.GetComponent<NFPM>();
                        buttono.Death();                       
                    }                 
                }                             
            }        
    }
}
