﻿using UnityEngine;
using System.Collections;

public class DudeMove : MonoBehaviour
{
    public Transform[] waypoints;
    int cur = 0;

    public float speed = 0.3f;

    Vector2 p;


    // Use this for initialization
    void Start()
    {
        
    }

    void FixedUpdate()
    {
        if (transform.position != waypoints[cur].position)
        {
            Vector2 p = Vector2.MoveTowards(transform.position,
                                            waypoints[cur].position,
                                            speed);
            GetComponent<Rigidbody2D>().MovePosition(p);
        }

        else
        {
            //cur = (cur + 1) % waypoints.Length;

            if (cur < waypoints.Length -1)
                cur++;
            else
                cur = 0;

            
        }
        Debug.Log("Current:" + cur + "Length: " + waypoints.Length);   
    }

    // Update is called once per frame
    
    
}
